library(shiny)
runExample("01_hello")
